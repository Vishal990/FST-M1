package examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumTest {
    public static void main(String[] args) {
        //web driver object
        WebDriver driver = new FirefoxDriver();

        // Open a browser
        driver.get("https://training-support.net");
        //Locate about us link
        driver.findElement(By.xpath("//*[@id=\"about-link\"]")).click();
        // Close the browser
       // driver.close();

    }
}
