package examples;

public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello world");
        String txt = "Vishal is  a full stack tester";
        System.out.println("The length of this text is " + txt.length());
    }


}
