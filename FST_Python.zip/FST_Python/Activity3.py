# get the user names
player1 = input("What is player 1's name? ")
player2 = input("What is player 2's name? ")

# Get the user's choice
player1_answer = input(player1 + " do you want to choose rock, paper or scissors?").lower()
player2_answer = input(player2 + " do you want to choose rock, paper or scissors?").lower()

# run the alogo to see who wins
if player1_answer == player2_answer:
    print("Its a tie !!")
elif player1_answer == 'rock':
    if player2_answer == 'scissors':
        print("rock wins !!")
    else:
        print("paper wins !!")
elif player1_answer == 'scissors':
    if player2_answer == 'paper':
        print ("scissors win !!")
    else:
        print ("rock wins !!")
elif player1_answer == 'paper':
    if player2_answer == 'rock':
        print("paper wins !!")
    else:
        print ("scissors wins !!")
else:
        print("Invalid input! You have not entered rock, paper or scissors, try again.")