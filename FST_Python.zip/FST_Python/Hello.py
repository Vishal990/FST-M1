print("Hello World")            # Strings

a = "Hello world"
print (a[2:5])
splitString = a.split()
print (splitString)

age = 38
txt = "My name is Vishal and I am {}"
print (txt.format(age))

x = 20  # int
y = 2.5  # float
z = 1j   # complex

print (type(x))     # gives type

